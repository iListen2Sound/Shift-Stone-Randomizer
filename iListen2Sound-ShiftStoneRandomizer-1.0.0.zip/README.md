# Shift Stone Randomizer

Randomize your shift stones

## Shiftstone Case:

-  Blacklist: Blacklists stones from the randomizer. Blacklisted stones can still be manually equipped. You can re-enable shift stones by pressing the button when you only have blacklisted stones equipped. Having an enabled stone and a blacklisted stone will add the enabled stone to the blacklist
-  Hand: Choose to only randomize one hand. 
- Save Loadout: Creates a loadout based on the current stones you're wearing and your locked hand.

## Shiftstone swapper

- Front button: Same as default
- Right Button: Equips randomized shift stones
- Left Button: Equips your loadout stones
- Rear Button: Clears your shift stones
